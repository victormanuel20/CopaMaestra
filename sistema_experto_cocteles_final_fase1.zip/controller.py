import pandas as pd
from interface import PrologEngine

class CoctelController:
    def __init__(self, view):
        self.view = view
        self.engine = PrologEngine()
        self.data_calificaciones = None
        self.data_cocktails = None

    def cargar_datos(self):
        print("📦 Cargando bases de datos...")

        try:
            self.data_calificaciones = pd.read_csv("data/base_calificaciones_cocteles_6000.csv")
            self.data_cocktails = pd.read_excel("data/cocktails.xlsx")

            print(f"✅ Calificaciones cargadas: {len(self.data_calificaciones)} registros")
            print(self.data_calificaciones.head(3))
            print("...")

            print(f"✅ Cócteles cargados: {len(self.data_cocktails)} registros")
            print(self.data_cocktails[['id', 'Drink', 'Ingredient1', 'DrinkThumb']].head(3))
            print("...")

        except FileNotFoundError:
            print("❌ Error: uno de los archivos no fue encontrado.")
        except Exception as e:
            print(f"❌ Error al cargar los datos: {e}")
        else:
            print("✔️ Datos cargados correctamente.")
