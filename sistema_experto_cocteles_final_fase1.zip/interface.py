class PrologEngine:
    def __init__(self):
        pass

    def cargar_resultados(self, data):
        pass
