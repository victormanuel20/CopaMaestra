import tkinter as tk
from tkinter import messagebox

# Variables globales para capturar datos del usuario
usuario_data = {
    'edad': None,
    'estrato': None,
    'carrera': None,
    'genero': None
}

class VistaPrincipal:
    def __init__(self, controller):
        self.controller = controller
        self.root = tk.Tk()
        self.root.title("Sistema Experto - Recomendador de Cócteles")

        tk.Label(self.root, text="Edad:").grid(row=0, column=0, sticky='e')
        self.entry_edad = tk.Entry(self.root)
        self.entry_edad.grid(row=0, column=1)

        tk.Label(self.root, text="Estrato:").grid(row=1, column=0, sticky='e')
        self.entry_estrato = tk.Entry(self.root)
        self.entry_estrato.grid(row=1, column=1)

        tk.Label(self.root, text="Carrera:").grid(row=2, column=0, sticky='e')
        self.entry_carrera = tk.Entry(self.root)
        self.entry_carrera.grid(row=2, column=1)

        tk.Label(self.root, text="Género:").grid(row=3, column=0, sticky='e')
        self.entry_genero = tk.Entry(self.root)
        self.entry_genero.grid(row=3, column=1)

        tk.Button(self.root, text="Cargar Datos", command=self.cargar_datos).grid(row=4, column=0, pady=10)
        tk.Button(self.root, text="Recomendar Cóctel", command=self.recomendar_coctel).grid(row=4, column=1, pady=10)

    def cargar_datos(self):
        self.controller.cargar_datos()
        messagebox.showinfo("Carga de datos", "Bases de datos cargadas correctamente.")

    def recomendar_coctel(self):
        edad = self.entry_edad.get()
        estrato = self.entry_estrato.get()
        carrera = self.entry_carrera.get()
        genero = self.entry_genero.get()

        if not (edad and estrato and carrera and genero):
            messagebox.showerror("Error", "Por favor complete todos los campos.")
            return

        usuario_data['edad'] = int(edad)
        usuario_data['estrato'] = int(estrato)
        usuario_data['carrera'] = carrera
        usuario_data['genero'] = genero

        print("✅ Datos ingresados por el usuario:")
        for key, value in usuario_data.items():
            print(f"- {key.capitalize()}: {value}")

    def iniciar(self):
        self.root.mainloop()
